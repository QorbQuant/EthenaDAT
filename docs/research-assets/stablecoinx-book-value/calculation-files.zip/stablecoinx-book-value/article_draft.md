# What is StablecoinX's book value per share?

Balance-sheet review / June 30, 2026 10-Q

By [Qorban Ferrell · @Degenerate\_DeFi](https://ethenadash.com/about/) · Published 12 October 2026 · Balance sheet at June 30, 2026 · Prices to the October 8, 2026 close · Sources read October 6 to 9, 2026 UTC

StablecoinX's book value, its total assets less total liabilities, was $214.3 million at June 30, 2026, or $8.92 per Class A share, in the balance sheet of its second-quarter report on Form 10-Q. [Read the filed financial statements](https://www.sec.gov/Archives/edgar/data/2080215/000121390026090250/ea0301482-10q_stable.htm). ENA, the Ethena governance token the company holds as its treasury, accounted for $212.9 million of it. The company carries ENA at cost less impairment, $0.07024 a token at June 30. That is close to $0.0702, ENA's lowest trade on Kraken, a crypto exchange, between the June 25 merger and June 30.

StablecoinX Inc.'s Class A stock trades on Nasdaq as USDE. Token NAV, this site's measure, is the market value of the ENA alone, and token NAV per share divides it by the Class A shares. The 10-Q lists three lots of ENA received at the merger, 3,031,404,421 tokens in all.

The carrying value does not rise with ENA's price. At the October 8 close the reported tokens were worth $619.3 million at Kraken's price, 2.9 times their carrying value, which put token NAV per share at $25.66. USDE closed that day at $12.79, which was 1.43 times June 30 book value per share and 0.50 times token NAV per share.

## ENA made up almost all of the June 30 balance sheet

| Balance sheet at June 30, 2026 | $ million |
| --- | ---: |
| ENA, at cost less impairment | 212.9 |
| Cash | 18.9 |
| Other assets | 0.8 |
| Total assets | 232.6 |
| Convertible notes owed to former sponsors | 6.9 |
| Accrued expenses | 6.0 |
| Warrant liability | 4.7 |
| Other liabilities | 0.7 |
| Total liabilities | 18.3 |
| Book value | 214.3 |

The convertible notes were loans from the former sponsors of TLGY Acquisition Corporation, the blank-check company in the June 25 merger. The warrant liability was the value of the 11,499,988 public warrants, which trade on Nasdaq as USDEW, at their quoted price.

Everything other than ENA, net of all liabilities, came to $1.35 million, or $0.06 per Class A share. Cash of $18.9 million slightly exceeded total liabilities of $18.3 million. The other assets were $602,000 of software, 33.91 restricted ETH worth $53,366, $67,359 of prepaid expenses and other current assets, and a receivable of $61,468 from Ethena. That receivable equals the quarter's fees for the company's decentralized verifier node, a service that checks cross-chain messages for Ethena's tokens, and Ethena pays those fees in ENA.

Book value per share counts Class A shares only. The 10-Q leaves the 3,157,754 Class B shares out of its loss per share, because they carry votes and no right to dividends or to assets in a liquidation. Divided across both classes, book value would come to $7.88 a share.

## The 10-Q carries ENA close to its lowest trade since the merger

The 10-Q says ENA falls outside ASC 350-60, the accounting standard that puts crypto assets at fair value, because Ethena, a related party, created it. StablecoinX therefore carries ENA as an intangible asset at cost less impairment. Cost was $249.1 million, the June 25 value of the three lots of ENA received at the merger, and each lot works out to $0.08218 a token.

Each quarter the company tests the tokens for impairment. When the test finds an impairment, the company writes the tokens down to the lowest intraday price quoted on an active exchange since it acquired them and does not write them back up if the price recovers. The company records a gain only when it sells tokens. The second quarter's impairment was $36.2 million, which left $212.9 million, or $0.07024 a token. ENA's lowest trade on Kraken from June 25 to June 30 was $0.0702, on June 30, $0.00004 below the carrying value per token, so the company's write-down price was not Kraken's lowest ENA/USD trade. The 10-Q does not name its price source.

The 33.91 ETH fall within ASC 350-60, so the company carries them at fair value.

The results release of August 14 priced the same tokens at $0.07204, which it called ENA's closing price on June 30. That price sits near Kraken's $0.0721 at the end of the UTC day, hours after the 4 pm New York close of $0.0707 used below. The release put the ENA at $218.4 million, or about $9.09 per Class A share, and a footnote said the financial statements carry ENA at cost less impairment. Rebuilt from the 10-Q's lots, the release's figure is $218,382,374, and book value came to $4,115,200 less. Carrying ENA at $0.07024 a token instead of $0.07204 took $5,463,533 off, and everything other than ENA, net of all liabilities, added back $1,348,333.

## USDE closed above June 30 book value from September 18 to October 8

![Line chart per Class A share from June 30 to October 8, 2026. Token NAV per share at ENA's price at the 4 pm close, $8.92 on June 30, a high of $33.04 on September 25 and $25.66 on October 8. USDE's close, $2.75 on June 30, first above book value on September 18 at $10.19, and $12.79 on October 8. Book value per Class A share at June 30, $8.92, flat across the chart.](/research-assets/stablecoinx-book-value/chart_book_value.svg)

*StablecoinX 10-Q, Kraken ENA/USD and S&P Global Market Intelligence closes through StockAnalysis · ENA priced at 4 pm New York time · Token NAV per share on 24,029,375 Class A shares to September 29 and a derived 24,139,375 from September 30*

At the June 30 close ENA was $0.0707 on Kraken, which put token NAV per share at $8.92, the same as book value per share to the cent. USDE closed at $2.75, or 0.31 times book value per share. Its lowest close came on July 24, at $1.43, or 0.16 times book value per share. USDE first closed above $8.92 on September 18, at $10.19, and closed above it at all 15 sessions from then to October 8.

Token NAV per share peaked at $33.04 on September 25, the day of USDE's highest close, $17.25, or 1.93 times book value per share. At every close from June 30 to October 8, USDE was below token NAV per share, at 0.13 to 0.52 times.

The chart holds book value per share at the June 30 figure, the latest in a filing. The September 30 balance sheet is due with the third-quarter 10-Q by November 16 if the company stays a non-accelerated filer and files without an extension, as the [lock-up review](https://ethenadash.com/research/stablecoinx-lock-up-waiver-2026-10-05/) explained.

## What changed after June 30

The company restructured the notes owed to the former sponsors. On August 21 it agreed to pay 5% of their original principal in cash, 47.5% in Tranche A warrants priced at $1.00 each and 47.5% in Tranche B warrants priced at $0.75 each, and the former sponsors waived their claims, according to a current report on Form 8-K of August 24. Applied to the $6,879,325 on the balance sheet, those percentages give the 3,267,679 Tranche A warrants in the resale prospectus of September 14, its 4,356,907 Tranche B warrants to within two, and $343,966 in cash. The 8-K does not say how the company accounts for the new warrants.

The liability for the public warrants moves with USDEW. At USDEW's June 30 close of $0.41, the 11,499,988 public warrants come to the $4,715,000 on the balance sheet, to the nearest thousand dollars. At USDEW's September 30 close of $5.17, the same method gives $59.5 million, $54.7 million more than at June 30 and equal to 26% of June 30 book value. That figure is arithmetic on a quoted price and leaves out every other change after June 30, including the Tranche A and B warrants. Under that method a higher liability lowers book value by the same amount.

Five directors each received 22,000 restricted Class A shares on September 30, according to their insider reports on Form 4 of October 2. Added to the 24,029,375 shares on the 10-Q's cover, they give 24,139,375, a derived count that no filing states.

Under the 10-Q's policy the carrying value of the tokens held at June 30 can fall but not rise. ENA that arrives later, such as the verifier node fees, carries its own cost. Kraken's lowest ENA trade from July 1 to September 30 was $0.0706, on July 1, 0.5% above the carrying value of $0.07024. Prices differ slightly across exchanges, so this review cannot show whether ENA traded below $0.07024 elsewhere in the quarter.

No filing read for this review gave an ENA count dated after the June 25 merger. The resale prospectus of September 14 said the company held approximately 3.03 billion ENA as a result of the closing. The company's filing list, read at 21:02 UTC on October 9, showed nothing filed after the directors' Forms 4.

## How this review counts

Balance-sheet figures come from the 10-Q filed on August 14, 2026, whose interim statements are unaudited. ENA's price at the close is the last trade before 20:00 UTC on Kraken's ENA/USD market, the close of its 4-hour candle from 16:00 to 20:00 UTC, which was 4 pm in New York on every date here. Kraken's daily candles give the lowest trade on each UTC day. USDE and USDEW closes come from S&P Global Market Intelligence through StockAnalysis. USDE's matched this site's dataset at all 71 sessions from June 30 to October 8.

Per-share figures divide by Class A shares, the reported 24,029,375 to September 29 and the derived 24,139,375 from September 30, with book value per share on the June 30 count. Token NAV here uses the 3,031,404,421 ENA in the 10-Q's three lots. In its dataset generated at 18:45 UTC on October 9, this site's StablecoinX dashboard used 3,029,000,000 ENA, the approximate figure in the merger press release and 0.08% fewer than the 10-Q's lots. It priced ENA at 00:00 UTC, which put USDE at 0.45 times token NAV per share on October 8.

## What these figures leave out

The ENA count is the sum of the three lots the company reported receiving at the June 25 merger, and nothing here verifies a wallet balance. A waiver that took effect on October 5 ended the lock-ups, the contractual limits on when the company could sell its ENA. The company may now sell ENA with the approvals the lock-up review described, and a sale would show in the reported count only in a later filing. Token NAV leaves out the cash, the other assets and every liability, prices locked and unlocked tokens alike and ignores any tax on a sale above cost.

Book value per share and token NAV per share both divide by Class A shares outstanding and add no shares for the 11,499,988 public warrants or the 7,624,586 Tranche A and B warrants, which the [warrant guide](https://ethenadash.com/research/usdew-warrants/) covers. Book value already subtracts the public warrants' June 30 liability.

## Reproduce the numbers

The main script checks every input against its recorded hash, that the balance sheet adds up, that the three ENA lots sum to the gross carrying amount at one price per token, that the carrying value per token sits within $0.00005 of Kraken's lowest trade to June 30, that the release's $218.4 million and $9.09 reproduce, that the warrant liability and the Tranche A and B counts follow from the filed figures, and that this site's dataset agrees on USDE's closes and the share count. If any check fails, the script stops before writing its tables. Download the [balance-sheet summary](/research-assets/stablecoinx-book-value/balance_sheet.csv), the [values per share at each close](/research-assets/stablecoinx-book-value/per_share_by_session.csv), or the [calculation files and source inputs](/research-assets/stablecoinx-book-value/calculation-files.zip).

```text
book value per Class A share = stockholders' equity ÷ Class A shares
                             = 214,267,174 ÷ 24,029,375 = $8.92 at June 30
carrying value per token     = ENA carrying value ÷ ENA count
                             = 212,918,841 ÷ 3,031,404,420.94 = $0.07024 at June 30
token NAV per share          = ENA price at the close × ENA count ÷ Class A shares
                             = 0.2043 × 3,031,404,420.94 ÷ 24,139,375 = $25.66 on October 8
times book value             = USDE close ÷ book value per Class A share
                             = 12.79 ÷ 8.92 = 1.43 on October 8
```

The [StablecoinX dashboard](https://ethenadash.com/stablecoinx/) tracks USDE's share price against the ENA treasury the company reports, the [mNAV guide](https://ethenadash.com/research/stablecoinx-mnav/) explains token NAV and mNAV, USDE's price divided by token NAV per share, and the [methodology page](https://ethenadash.com/methodology/) defines the site's figures.

Analysis of public market data. Not investment advice.
